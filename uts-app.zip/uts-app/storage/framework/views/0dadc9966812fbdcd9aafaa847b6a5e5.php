

<?php $__env->startSection('content'); ?>

<a href="<?php echo e(route('books.create')); ?>" class="btn btn-primary">Add New</a>

<table class="table">
    <tr>
        <th>ID</th>
        <th>Title</th>
        <th>Author</th>
        <th>Page</th>
        <th>Year</th>
        <th>Action</th>
    </tr>

    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($book->id); ?></td>
            <td><?php echo e($book->title); ?></td>
            <td><?php echo e($book->author); ?></td>
            <td><?php echo e($book->page); ?></td>
            <td><?php echo e($book->year); ?></td>
            <td>
                <a href="<?php echo e(route('books.show', $book->id)); ?>" class="btn btn-success">Show</a>
                <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="btn btn-warning">Edit</a>
                <form onclick="return confirm('Are you sure?')" action="<?php echo e(route('books.destroy', $book->id)); ?>" 
                method="post" style="display: inline">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button class="btn btn-danger">Delete</button>
                </form>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</table>

<?php echo e($books->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andiwira\uts-app\resources\views/books/index.blade.php ENDPATH**/ ?>