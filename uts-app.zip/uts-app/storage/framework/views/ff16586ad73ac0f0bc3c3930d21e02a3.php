

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('books.store')); ?>" method="post">
    <?php echo csrf_field(); ?>
    <label for="">Title</label><br>
    <input type="text" name="title" id=""><br>

    <label for="">Author</label><br>
    <input type="text" name="author" id=""><br>

    <label for="">Page</label><br>
    <input type="number" name="page" id=""><br>

    <label for="">Year</label><br>
    <input type="number" name="year" id=""><br><br>

    <input type="submit" value="Save" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andiwira\uts-app\resources\views/books/create.blade.php ENDPATH**/ ?>