

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('books.update', $book->id)); ?>" method="post">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <label for="">Title</label><br>
    <input type="text" name="title" id="" value="<?php echo e($book->title); ?>"><br>

    <label for="">Author</label><br>
    <input type="text" name="author" id="" value="<?php echo e($book->author); ?>"><br>

    <label for="">Page</label><br>
    <input type="number" name="page" id="" value="<?php echo e($book->page); ?>"><br>

    <label for="">Year</label><br>
    <input type="number" name="year" id="" value="<?php echo e($book->year); ?>"><br><br>

    <input type="submit" value="Update" class="btn btn-primary">
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andiwira\uts-app\resources\views/books/edit.blade.php ENDPATH**/ ?>