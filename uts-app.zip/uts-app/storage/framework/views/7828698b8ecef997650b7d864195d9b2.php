

<?php $__env->startSection('content'); ?>

<h3><?php echo e($book->title); ?></h3>

<p>Written by: <?php echo e($book->author); ?></p>
<p>Number of page: <?php echo e($book->page); ?></p>
<p>Published on: <?php echo e($book->year); ?></p>

<a href="<?php echo e(route('books.index')); ?>" class="btn btn-secondary">Back to Index</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('books.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\andiwira\uts-app\resources\views/books/show.blade.php ENDPATH**/ ?>